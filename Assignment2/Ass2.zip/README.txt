Author: Jingshi Yang

Project
Based on OpenCV, implement Obeject detection and tracking by using ORB and MultiTracker, KCF tracker
Output includes rectangles (display the estimated location) and tracing lines (desribe the path of the motion of the objects)

Run
python object-tracking.py video_name.mp4  